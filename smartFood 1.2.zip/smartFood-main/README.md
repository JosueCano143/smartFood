# smartFood
Smart Food simulation: algorithm for suggestion of foods that replace the consumption of seafood; Trepcamp
